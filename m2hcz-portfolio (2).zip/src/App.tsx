/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform, animate } from "motion/react";
import { Server, Shield, Code, X, Terminal, Layout, Hammer, LogIn, LogOut } from "lucide-react";
import { db, auth, login, logout, onAuthStateChanged, onSnapshot, doc, updateDoc, User, setDoc } from "./firebase";

export default function App() {
  const navItems = ["ABOUT", "GAMES", "PROJECTS", "STACK", "CONTACT"];
  const [selectedFeature, setSelectedFeature] = useState<null | number>(null);
  const [lang, setLang] = useState<"EN" | "PT">("EN");
  const [user, setUser] = useState<User | null>(null);
  const [status, setStatus] = useState("open");

  // Auth listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // Firestore listener for status
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, "settings", "portfolio"), (docSnap) => {
      if (docSnap.exists()) {
        setStatus(docSnap.data().status);
      } else {
        // Initialize if doesn't exist (will only work if rules allow)
        console.log("Settings document not found.");
      }
    });
    return () => unsubscribe();
  }, []);

  const isAdmin = user?.email === "pietromedinalopes@gmail.com";

  const toggleStatus = async () => {
    if (!isAdmin) return;
    const newStatus = status === "open" ? "closed" : "open";
    try {
      await setDoc(doc(db, "settings", "portfolio"), {
        status: newStatus,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const handleAuth = async () => {
    if (user) {
      await logout();
    } else {
      try {
        await login();
      } catch (error) {
        console.error("Login failed:", error);
      }
    }
  };

  const translations = {
    EN: {
      nav: ["ABOUT", "GAMES", "PROJECTS", "STACK", "CONTACT"],
      hero: {
        role: "UI Maker · Builder · Intermediate Scripter",
        desc: "Crafting immersive interfaces and detailed environments. Intermediate scripter focused on functional gameplay systems and clean user experiences.",
        scroll: "SCROLL"
      },
      stats: {
        dev: "DEVELOPMENT",
        visits: "TOTAL GAME VISITS",
        members: "COMMUNITY MEMBERS"
      },
      about: {
        title: "About",
        me: "me",
        p1: "I am a creative developer with a focus on UI design and environmental building. With intermediate scripting skills, I bring static worlds to life through functional code and intuitive interfaces.",
        p2: "My work bridges the gap between aesthetic design and technical implementation. Whether it's building complex maps or designing seamless UIs, I ensure every detail contributes to a cohesive player experience.",
        meta: {
          location: "LOCATION",
          languages: "LANGUAGES",
          email: "EMAIL",
          github: "GITHUB",
          twitter: "TWITTER",
          status: "STATUS",
          open: "Open to work"
        }
      },
      features: [
        {
          title: "UI Design",
          description: "Creating intuitive and visually stunning user interfaces.",
          details: "Specialized in crafting clean, modern UIs that enhance player engagement. Focused on usability, layout, and aesthetic consistency across all platforms."
        },
        {
          title: "Building",
          description: "Constructing detailed and immersive environments.",
          details: "Expertise in environmental design and map building. From small assets to large-scale worlds, I focus on lighting, composition, and atmospheric storytelling."
        },
        {
          title: "Scripting",
          description: "Implementing functional systems and gameplay logic.",
          details: "Intermediate scripter with experience in Luau and game logic. Building modular systems for interaction, data management, and dynamic gameplay elements."
        }
      ],
      modal: {
        close: "CLOSE"
      }
    },
    PT: {
      nav: ["SOBRE", "JOGOS", "PROJETOS", "STACK", "CONTATO"],
      hero: {
        role: "UI Maker · Builder · Scripter Intermediário",
        desc: "Criando interfaces imersivas e ambientes detalhados. Scripter intermediário focado em sistemas de jogabilidade funcionais e experiências de usuário limpas.",
        scroll: "ROLAR"
      },
      stats: {
        dev: "DESENVOLVIMENTO",
        visits: "TOTAL DE VISITAS EM JOGOS",
        members: "MEMBROS DA COMUNIDADE"
      },
      about: {
        title: "Sobre",
        me: "mim",
        p1: "Sou um desenvolvedor criativo com foco em design de UI e construção de ambientes. Com habilidades intermediárias de scripting, dou vida a mundos estáticos através de código funcional e interfaces intuitivas.",
        p2: "Meu trabalho une o design estético à implementação técnica. Seja construindo mapas complexos ou projetando UIs fluidas, garanto que cada detalhe contribua para uma experiência coesa do jogador.",
        meta: {
          location: "LOCALIZAÇÃO",
          languages: "IDIOMAS",
          email: "E-MAIL",
          github: "GITHUB",
          twitter: "TWITTER",
          status: "STATUS",
          open: "Disponível para trabalho"
        }
      },
      features: [
        {
          title: "Design de UI",
          description: "Criando interfaces de usuário intuitivas e visualmente impressionantes.",
          details: "Especializado em criar UIs limpas e modernas que aumentam o engajamento do jogador. Focado em usabilidade, layout e consistência estética em todas as plataformas."
        },
        {
          title: "Construção (Building)",
          description: "Construindo ambientes detalhados e imersivos.",
          details: "Experiência em design ambiental e construção de mapas. De pequenos assets a mundos em larga escala, foco em iluminação, composição e narrativa atmosférica."
        },
        {
          title: "Scripting",
          description: "Implementando sistemas funcionais e lógica de jogo.",
          details: "Scripter intermediário com experiência em Luau e lógica de jogo. Construindo sistemas modulares para interação, gerenciamento de dados e elementos dinâmicos de jogabilidade."
        }
      ],
      modal: {
        close: "FECHAR"
      }
    }
  };

  const t = translations[lang];

  const features = [
    {
      id: 1,
      icon: <Layout className="w-6 h-6" />,
      title: t.features[0].title,
      description: t.features[0].description,
      details: t.features[0].details
    },
    {
      id: 2,
      icon: <Hammer className="w-6 h-6" />,
      title: t.features[1].title,
      description: t.features[1].description,
      details: t.features[1].details
    },
    {
      id: 3,
      icon: <Code className="w-6 h-6" />,
      title: t.features[2].title,
      description: t.features[2].description,
      details: t.features[2].details
    }
  ];

  return (
    <div className={`min-h-screen transition-colors duration-700 font-sans selection:bg-white selection:text-black overflow-x-hidden bg-[#050505]`}>
      {/* Grid Background */}
      <div className="fixed inset-0 grid-bg pointer-events-none opacity-20" />
      <div className="fixed inset-0 scanline pointer-events-none" />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 w-full z-50 px-8 py-6 flex justify-between items-center bg-[#050505]/80 backdrop-blur-md border-b border-white/5">
        <div className="flex items-center gap-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            onClick={handleAuth}
            className="text-xl font-black tracking-tighter text-white cursor-pointer select-none active:scale-95 transition-transform flex items-center gap-2 group"
            title={user ? "Logout" : "Login"}
          >
            mDnH4rd.
            {isAdmin && (
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.6)]" />
            )}
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-2 text-[8px] font-bold tracking-widest text-white/30"
          >
            <button 
              onClick={() => setLang("EN")}
              className={`hover:text-white transition-colors ${lang === "EN" ? "text-white" : ""}`}
            >
              EN
            </button>
            <span className="opacity-50">/</span>
            <button 
              onClick={() => setLang("PT")}
              className={`hover:text-white transition-colors ${lang === "PT" ? "text-white" : ""}`}
            >
              PT
            </button>
          </motion.div>
        </div>
        <div className="hidden md:flex gap-8">
          {t.nav.map((item, index) => (
            <motion.a
              key={item}
              href={`#${translations.EN.nav[index].toLowerCase()}`}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="text-[10px] font-bold tracking-[0.2em] text-white/50 hover:text-white transition-colors"
            >
              {item}
            </motion.a>
          ))}
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative h-screen flex flex-col justify-center px-8 md:px-24 overflow-hidden pt-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="h-[1px] w-12 bg-white/30" />
              <span className="text-[10px] font-mono tracking-[0.4em] text-white/40 uppercase">
                {t.hero.role}
              </span>
            </div>

            <h1 className="text-8xl md:text-[12rem] font-black tracking-tighter font-display mb-6 leading-[0.8] text-white">
              mDnH4rd<span className="text-white/20">.</span>
            </h1>

            <p className="text-lg md:text-xl text-white/50 leading-relaxed max-w-xl font-light mb-12 border-l-2 border-white/10 pl-6">
              {t.hero.desc}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 md:gap-12">
              <StatItem value="12" suffix="yr" label={t.stats.dev} />
              <StatItem value="350" suffix="M+" label={t.stats.visits} />
              <StatItem value="2" suffix="M+" label={t.stats.members} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="hidden lg:block relative"
          >
            <div className="aspect-square w-full max-w-md mx-auto relative">
              <div className="absolute inset-0 border border-white/10 rounded-full animate-[spin_20s_linear_infinite]" />
              <div className="absolute inset-4 border border-white/5 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-[10rem] font-black text-white/5 font-display select-none">
                  01
                </div>
              </div>
              {/* Technical markers */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-full text-[10px] font-mono text-white/20 tracking-widest mb-4">
                LAT: -23.5505 / LONG: -46.6333
              </div>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-16 left-8 flex flex-col items-center gap-3"
        >
          <motion.div
            animate={{ 
              y: [0, -8, 0],
              opacity: [0.2, 0.4, 0.2]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="text-white/20"
          >
            <Terminal className="w-4 h-4" />
          </motion.div>
          
          <button 
            onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
            className="rotate-90 origin-left translate-x-3 group"
          >
            <span className="text-[8px] font-bold tracking-[0.3em] text-white/20 uppercase group-hover:text-white transition-colors cursor-pointer">
              {t.hero.scroll}
            </span>
          </button>
        </motion.div>
      </main>

      {/* About Me Section */}
      <section id="about" className="py-32 px-8 md:px-24 border-t border-white/5">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="flex items-center gap-4 mb-12">
            <div className="h-[1px] w-8 bg-white/30" />
            <span className="text-[10px] font-mono tracking-[0.3em] text-white/40 uppercase">001</span>
          </div>

          <div className="grid lg:grid-cols-[1.5fr_1fr] gap-16 mb-24">
            {/* Left Column: Text */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-6xl md:text-8xl font-black tracking-tighter text-white mb-12 font-display flex items-baseline gap-4">
                {t.about.title} <span className="text-transparent stroke-white stroke-1" style={{ WebkitTextStroke: '1px rgba(255,255,255,0.3)' }}>{t.about.me}</span>
              </h2>
              
              <div className="space-y-8 text-lg md:text-xl text-white/60 leading-relaxed font-light">
                <p>
                  {t.about.p1}
                </p>
                <p>
                  {t.about.p2}
                </p>
              </div>
            </motion.div>

            {/* Right Column: Metadata */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex flex-col justify-end"
            >
              <div className="space-y-6 border-t border-white/5 pt-8">
                <MetadataItem label={t.about.meta.location} value="Brazil" />
                <MetadataItem label={t.about.meta.languages} value="Portuguese · English" />
                <MetadataItem label={t.about.meta.email} value="m2hczs@proton.me" isLink href="mailto:m2hczs@proton.me" />
                <MetadataItem label={t.about.meta.github} value="github.com/m2hcz" isLink href="https://github.com/m2hcz" />
                <MetadataItem label={t.about.meta.twitter} value="@inf0secc" isLink href="https://twitter.com/inf0secc" />
                <motion.div 
                  whileHover={{ x: 5 }}
                  className="flex justify-between items-center py-3 px-2 -mx-2 group cursor-default hover:bg-white/[0.02] rounded-lg transition-colors"
                >
                  <span className="text-[10px] font-bold tracking-[0.2em] text-white/20 uppercase group-hover:text-white/40 transition-colors">{t.about.meta.status}</span>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full animate-pulse ${status === "open" ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.6)]" : "bg-red-400 shadow-[0_0_8px_rgba(248,113,113,0.6)]"}`} />
                      <span className={`text-sm font-medium ${status === "open" ? "text-emerald-400" : "text-red-400"}`}>
                        {status === "open" ? (lang === "EN" ? "Open to work" : "Disponível") : (lang === "EN" ? "Closed to work" : "Indisponível")}
                      </span>
                    </div>
                    
                    {isAdmin && (
                      <button 
                        onClick={toggleStatus}
                        className="text-[8px] font-black tracking-widest bg-white text-black px-2 py-1 rounded hover:bg-zinc-200 transition-colors uppercase"
                      >
                        Toggle
                      </button>
                    )}
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>

          {/* Interactive Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((feature, idx) => (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.01, y: -2 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                onClick={() => setSelectedFeature(idx)}
                className="group p-8 bg-white/[0.02] border border-white/5 rounded-2xl cursor-pointer hover:bg-white/[0.04] hover:border-white/20 transition-all"
              >
                <div className="p-3 bg-white/5 rounded-xl text-white/80 w-fit mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-white text-xl font-bold tracking-tight mb-3">{feature.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
            <div className="p-8 bg-white/[0.02] border border-white/5 rounded-2xl flex flex-col justify-center items-center text-center">
              <div className="text-[10px] font-mono text-white/20 tracking-[0.5em] uppercase mb-4">System Status</div>
              <div className="text-2xl font-black text-white tracking-tighter">OPERATIONAL</div>
            </div>
          </div>
        </div>
      </section>

      {/* Modal / Overlay */}
      <AnimatePresence>
        {selectedFeature !== null && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedFeature(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-zinc-900 border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
              
              <button 
                onClick={() => setSelectedFeature(null)}
                className="absolute top-6 right-6 p-2 text-white/40 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="p-4 bg-white/5 rounded-2xl text-white w-fit mb-8">
                {features[selectedFeature].icon}
              </div>

              <h2 className="text-3xl font-black tracking-tighter text-white mb-4 font-display">
                {features[selectedFeature].title}
              </h2>
              
              <p className="text-white/60 leading-relaxed text-lg">
                {features[selectedFeature].details}
              </p>

              <div className="mt-12 flex justify-end">
                <button 
                  onClick={() => setSelectedFeature(null)}
                  className="px-8 py-3 bg-white text-black text-xs font-bold tracking-[0.2em] rounded-full hover:bg-white/90 transition-colors"
                >
                  {t.modal.close}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MetadataItem({ label, value, isLink, href }: { label: string; value: string; isLink?: boolean; href?: string }) {
  return (
    <motion.div 
      whileHover={{ x: 5 }}
      className="flex justify-between items-center py-3 px-2 -mx-2 border-b border-white/5 last:border-0 group cursor-default hover:bg-white/[0.02] rounded-lg transition-colors"
    >
      <span className="text-[10px] font-bold tracking-[0.2em] text-white/20 uppercase group-hover:text-white/40 transition-colors">{label}</span>
      {isLink ? (
        <a 
          href={href} 
          target={href?.startsWith('http') ? "_blank" : undefined}
          rel={href?.startsWith('http') ? "noopener noreferrer" : undefined}
          className="text-sm text-white/80 hover:text-white underline underline-offset-4 decoration-white/20 transition-colors"
        >
          {value}
        </a>
      ) : (
        <span className="text-sm text-white/80 group-hover:text-white transition-colors">{value}</span>
      )}
    </motion.div>
  );
}

function StatItem({ value, suffix, label }: { value: string; suffix: string; label: string }) {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest) => Math.round(latest));
  const [displayValue, setDisplayValue] = useState("0");

  useEffect(() => {
    const numericValue = parseInt(value);
    if (isNaN(numericValue)) {
      setDisplayValue(value);
      return;
    }

    const controls = animate(count, numericValue, {
      duration: 2,
      ease: "easeOut",
    });

    return controls.stop;
  }, [value, count]);

  useEffect(() => {
    return rounded.on("change", (latest) => {
      setDisplayValue(latest.toString());
    });
  }, [rounded]);

  return (
    <div className="flex gap-4 items-start group min-w-0">
      <div className="w-[1px] h-10 bg-gradient-to-b from-white/40 to-transparent group-hover:from-white transition-all duration-500 shrink-0" />
      <div className="flex flex-col min-w-0">
        <div className="flex items-baseline shrink-0">
          <motion.span className="text-3xl md:text-4xl font-black tracking-[-0.05em] font-display bg-gradient-to-br from-white via-white to-white/20 bg-clip-text text-transparent">
            {displayValue}
          </motion.span>
          <span className="text-sm md:text-lg font-bold text-white/40 ml-1">{suffix}</span>
        </div>
        <span className="text-[8px] md:text-[9px] font-mono tracking-[0.1em] text-white/30 mt-1 group-hover:text-white/50 transition-colors leading-tight uppercase">
          {label}
        </span>
      </div>
    </div>
  );
}

